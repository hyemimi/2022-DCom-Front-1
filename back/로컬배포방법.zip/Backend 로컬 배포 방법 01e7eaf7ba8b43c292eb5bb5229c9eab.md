# Backend 로컬 배포 방법

### Pre Requirements

- **Docker Compose** 설치 되어 있어야 함. 다음 명령어를 통해 버전이 잘 떴다면 설치 된 것.
    - 설치 되지 않았다면, Docker for windows 설치를 제대로 한건지 확인 할 것.
    
    ```bash
    docker-compose -v
    ```
    
- Java 설치 되어 있어야 함. 다음 명령어를 통해 버전이 잘 떴다면 설치 된 것.
    - 설치 되지 않았다면, [https://www.oracle.com/java/technologies/downloads/#java11](https://www.oracle.com/java/technologies/downloads/#java11) 에서 설치
    
    ```bash
    java -version
    ```
    
- Postman 설치 되어 있을 꺼라 믿어요…

### Spring 서버 실행 방법

- 먼저 두 파일을 다운로드 받은 후, 한 폴더에 넣어 준다.
    
    (서버 파일은 카톡으로 보내겠습니다)
    
    [docker-compose.yml](Backend%20%E1%84%85%E1%85%A9%E1%84%8F%E1%85%A5%E1%86%AF%20%E1%84%87%E1%85%A2%E1%84%91%E1%85%A9%20%E1%84%87%E1%85%A1%E1%86%BC%E1%84%87%E1%85%A5%E1%86%B8%2001e7eaf7ba8b43c292eb5bb5229c9eab/docker-compose.yml)
    
- 해당 폴더를 오른쪽 클릭 한 후 [Git Bash here…] 을 클릭 한다.
    - Docker를 통한 DBMS 실행. Spring 서버를 실행 하기 전에 수행 하여야 함.
    
    ```bash
    docker-compose up -d
    ```
    
    - Spring 서버 실행, 종료 시에는 Ctrl + C를 입력 하면 된다.
    
    ```bash
    java -jar api-0.0.1-SNAPSHOT.jar
    ```
    
    - Docker compose 종료 시 (DBMS 메모리 많이 잡아 먹어용)
    
    ```bash
    docker-compose down
    ```
    

### 서버 실행 후,

- [http://localhost:8080/swagger-ui/](http://localhost:8080/swagger-ui/) 에 문서 있음.
    - **http://localhost:8080**을 Base URL로 잡고 API 요청 하여 진행 하면 됨.